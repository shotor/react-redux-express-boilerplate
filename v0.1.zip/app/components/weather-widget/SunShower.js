import React, { Component } from 'react';

export default class SunShower extends Component {
  render() {
    return (
      <div className="icon">
        <div className="cloud"></div>
        <div className="sun">
          <div className="rays"></div>
        </div>
        <div className="rain"></div>
      </div>
    );
  }
}
