import React, { Component } from 'react';

export default class Windy extends Component {
  render() {
    return (
      <div className="icon">
        <svg version="1.1"
            id="wind"
            className="climacon climacon_wind"
            viewBox="15 15 70 70"
            enable-background="new 15 15 70 70">
            <g className="climacon_iconWrap climacon_iconWrap-wind">
                <g className="climacon_wrapperComponent climacon_componentWrap-wind">
                    <path fill="#455A64" stroke="white" stroke-opacity="1"
                    className="climacon_component climacon_component-stroke climacon_component-wind climacon_component-wind_curl"
                    d="M65.999,52L65.999,52h-3c-1.104,0-2-0.895-2-1.999c0-1.104,0.896-2,2-2h3c1.104,0,2-0.896,2-1.999c0-1.105-0.896-2-2-2s-2-0.896-2-2s0.896-2,2-2c0.138,0,0.271,0.014,0.401,0.041c3.121,0.211,5.597,2.783,5.597,5.959C71.997,49.314,69.312,52,65.999,52z"/>
                    <path fill="#455A64" stroke="white" stroke-opacity="1"
                    className="climacon_component climacon_component-stroke climacon_component-wind"
                    d="M55.999,48.001h-2h-6.998H34.002c-1.104,0-1.999,0.896-1.999,2c0,1.104,0.895,1.999,1.999,1.999h2h3.999h3h4h3h3.998h2c3.313,0,6,2.688,6,6c0,3.176-2.476,5.748-5.597,5.959C56.271,63.986,56.139,64,55.999,64c-1.104,0-2-0.896-2-2c0-1.105,0.896-2,2-2s2-0.896,2-2s-0.896-2-2-2h-2h-3.998h-3h-4h-3h-3.999h-2c-3.313,0-5.999-2.686-5.999-5.999c0-3.175,2.475-5.747,5.596-5.959c0.131-0.026,0.266-0.04,0.403-0.04l0,0h12.999h6.998h2c1.104,0,2-0.896,2-2s-0.896-2-2-2s-2-0.895-2-2c0-1.104,0.896-2,2-2c0.14,0,0.272,0.015,0.403,0.041c3.121,0.211,5.597,2.783,5.597,5.959C61.999,45.314,59.312,48.001,55.999,48.001z"/>
                </g>
            </g>
        </svg>
      </div>
    );
  }
}
