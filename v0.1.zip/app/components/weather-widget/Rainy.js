import React, { Component } from 'react';

export default class Rainy extends Component {
  render() {
    return (
      <div className="icon">
        <div className="cloud"></div>
        <div className="rain"></div>
      </div>
    );
  }
}
