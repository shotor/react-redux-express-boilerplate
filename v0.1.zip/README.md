react-redux-express-boilerplate
===============================

Simple boilerplate using `Webpack 2`.

More information to follow.

## Usage

Make sure all dependencies are installed

```
$ npm install
```

Then run one of the commands

## Commands

Start in dev mode with hot module reloading

```
$ npm run start:dev
```

Start in dev mode in electron with hot module reloading

```
$ npm run electron:start:dev
```