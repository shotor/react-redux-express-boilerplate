import React, { Component } from 'react';

export default class Cloudy extends Component {
  render() {
    return (
      <div className="icon">
        <div className="cloud"></div>
        <div className="cloud"></div>
      </div>
    );
  }
}
